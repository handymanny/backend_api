create procedure orders_create_audit(IN inOrderId int, IN inMessage text, IN inCode int)
BEGIN
  INSERT INTO audit (order_id, created_on, message, code)
         VALUES (inOrderId, NOW(), inMessage, inCode);
END;

