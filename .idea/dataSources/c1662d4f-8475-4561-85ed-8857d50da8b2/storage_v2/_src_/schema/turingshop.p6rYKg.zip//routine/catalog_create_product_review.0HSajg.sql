create procedure catalog_create_product_review(IN inCustomerId int, IN inProductId int, IN inReview text,
                                               IN inRating smallint(6))
BEGIN
  INSERT INTO review (customer_id, product_id, review, rating, created_on)
         VALUES (inCustomerId, inProductId, inReview, inRating, NOW());
END;

