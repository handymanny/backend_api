create procedure catalog_get_department_details(IN inDepartmentId int)
BEGIN
  SELECT name, description
  FROM   department
  WHERE  department_id = inDepartmentId;
END;

