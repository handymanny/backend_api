create procedure catalog_add_attribute(IN inName varchar(100))
BEGIN
  INSERT INTO attribute (name) VALUES (inName);
END;

