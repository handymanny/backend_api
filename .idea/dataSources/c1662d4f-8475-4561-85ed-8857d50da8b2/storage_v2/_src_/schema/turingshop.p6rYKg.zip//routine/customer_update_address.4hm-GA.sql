create procedure customer_update_address(IN inCustomerId int, IN inAddress1 varchar(100), IN inAddress2 varchar(100),
                                         IN inCity varchar(100), IN inRegion varchar(100), IN inPostalCode varchar(100),
                                         IN inCountry varchar(100), IN inShippingRegionId int)
BEGIN
  UPDATE customer
  SET    address_1 = inAddress1, address_2 = inAddress2, city = inCity,
         region = inRegion, postal_code = inPostalCode,
         country = inCountry, shipping_region_id = inShippingRegionId
  WHERE  customer_id = inCustomerId;
END;

