create procedure catalog_get_department_categories(IN inDepartmentId int)
BEGIN
  SELECT   *
  FROM     category
  WHERE    department_id = inDepartmentId
  ORDER BY category_id;
END;

