create procedure customer_update_credit_card(IN inCustomerId int, IN inCreditCard text)
BEGIN
  UPDATE customer
  SET    credit_card = inCreditCard
  WHERE  customer_id = inCustomerId;
END;

