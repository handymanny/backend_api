create procedure orders_set_date_shipped(IN inOrderId int)
BEGIN
  UPDATE orders SET shipped_on = NOW() WHERE order_id = inOrderId;
END;

