create procedure catalog_get_department_name(IN inDepartmentId int)
BEGIN
  SELECT name FROM department WHERE department_id = inDepartmentId;
END;

