create procedure customer_update_account(IN inCustomerId int, IN inName varchar(50), IN inEmail varchar(100),
                                         IN inPassword varchar(50), IN inDayPhone varchar(100),
                                         IN inEvePhone varchar(100), IN inMobPhone varchar(100))
BEGIN
  UPDATE customer
  SET    name = inName, email = inEmail,
         password = inPassword, day_phone = inDayPhone,
         eve_phone = inEvePhone, mob_phone = inMobPhone
  WHERE  customer_id = inCustomerId;
END;

