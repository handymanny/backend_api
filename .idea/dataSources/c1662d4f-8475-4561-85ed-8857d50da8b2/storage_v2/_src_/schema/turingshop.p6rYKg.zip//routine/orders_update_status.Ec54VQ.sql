create procedure orders_update_status(IN inOrderId int, IN inStatus int)
BEGIN
  UPDATE orders SET status = inStatus WHERE order_id = inOrderId;
END;

