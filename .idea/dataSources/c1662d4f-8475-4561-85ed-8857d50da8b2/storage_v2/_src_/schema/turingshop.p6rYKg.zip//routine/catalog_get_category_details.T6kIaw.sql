create procedure catalog_get_category_details(IN inCategoryId int)
BEGIN
  SELECT name, description
  FROM   category
  WHERE  category_id = inCategoryId;
END;

