create procedure catalog_add_department(IN inName varchar(100), IN inDescription varchar(1000))
BEGIN
  INSERT INTO department (name, description)
         VALUES (inName, inDescription);
END;

