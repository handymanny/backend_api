create procedure catalog_add_attribute_value(IN inAttributeId int, IN inValue varchar(100))
BEGIN
  INSERT INTO attribute_value (attribute_id, value)
         VALUES (inAttributeId, inValue);
END;

