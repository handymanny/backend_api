create procedure orders_set_auth_code(IN inOrderId int, IN inAuthCode varchar(50), IN inReference varchar(50))
BEGIN
  UPDATE orders
  SET    auth_code = inAuthCode, reference = inReference
  WHERE  order_id = inOrderId;
END;

