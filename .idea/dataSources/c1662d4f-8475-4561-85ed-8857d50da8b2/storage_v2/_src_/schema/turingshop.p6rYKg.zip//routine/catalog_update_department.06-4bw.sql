create procedure catalog_update_department(IN inDepartmentId int, IN inName varchar(100),
                                           IN inDescription varchar(1000))
BEGIN
  UPDATE department
  SET    name = inName, description = inDescription
  WHERE  department_id = inDepartmentId;
END;

