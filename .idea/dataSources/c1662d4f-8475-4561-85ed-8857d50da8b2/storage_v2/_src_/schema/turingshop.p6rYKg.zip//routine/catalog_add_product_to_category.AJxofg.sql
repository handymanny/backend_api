create procedure catalog_add_product_to_category(IN inCategoryId int, IN inName varchar(100),
                                                 IN inDescription varchar(1000), IN inPrice decimal(10, 2))
BEGIN
  DECLARE productLastInsertId INT;

  INSERT INTO product (name, description, price)
         VALUES (inName, inDescription, inPrice);

  SELECT LAST_INSERT_ID() INTO productLastInsertId;

  INSERT INTO product_category (product_id, category_id)
         VALUES (productLastInsertId, inCategoryId);
END;

