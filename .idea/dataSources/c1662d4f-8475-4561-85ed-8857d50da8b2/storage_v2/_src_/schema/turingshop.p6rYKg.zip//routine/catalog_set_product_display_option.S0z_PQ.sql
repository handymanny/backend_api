create procedure catalog_set_product_display_option(IN inProductId int, IN inDisplay smallint(6))
BEGIN
  UPDATE product SET display = inDisplay WHERE product_id = inProductId;
END;

