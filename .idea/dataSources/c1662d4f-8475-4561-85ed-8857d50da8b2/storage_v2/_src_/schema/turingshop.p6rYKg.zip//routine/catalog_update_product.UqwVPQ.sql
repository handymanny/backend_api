create procedure catalog_update_product(IN inProductId int, IN inName varchar(100), IN inDescription varchar(1000),
                                        IN inPrice decimal(10, 2), IN inDiscountedPrice decimal(10, 2))
BEGIN
  UPDATE product
  SET    name = inName, description = inDescription, price = inPrice,
         discounted_price = inDiscountedPrice
  WHERE  product_id = inProductId;
END;

